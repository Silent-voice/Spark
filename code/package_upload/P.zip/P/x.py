# -*- coding:utf-8 -*-

def method(x):
    json = __import__('json')
    a = __import__('A.a')
    pk = json.loads(x)
    domain = pk['domain']
    vec = a.method(domain)
    return (domain, vec)